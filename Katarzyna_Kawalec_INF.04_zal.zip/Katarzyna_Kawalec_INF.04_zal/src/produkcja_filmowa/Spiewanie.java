package produkcja_filmowa;

public interface Spiewanie {
    public void spiewac();
}
