package produkcja_filmowa;

import java.util.Objects;

public class Pracownik {
    String imie;
    String nazwisko;
    double wynagrodzeniePodst;

    public Pracownik(String imie, String nazwisko, double wynagrodzeniePodst) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.wynagrodzeniePodst = wynagrodzeniePodst;
    }

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    public double getWynagrodzeniePodst() {
        return wynagrodzeniePodst;
    }

    public void setWynagrodzeniePodst(double wynagrodzeniePodst) {
        this.wynagrodzeniePodst = wynagrodzeniePodst;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pracownik pracownik = (Pracownik) o;
        return Double.compare(pracownik.wynagrodzeniePodst, wynagrodzeniePodst) == 0 && imie.equals(pracownik.imie) && nazwisko.equals(pracownik.nazwisko);
    }

    @Override
    public int hashCode() {
        return Objects.hash(imie, nazwisko, wynagrodzeniePodst);
    }

    @Override
    public String toString() {
        return "Pracownik{" +
                "imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                ", wynagrodzeniePodst=" + wynagrodzeniePodst +
                '}';
    }
}
