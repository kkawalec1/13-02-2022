package produkcja_filmowa;

public class Main {

    public static void main(String[] args) {
        Rezyser rezyser1 = new Rezyser("Marcin","Szotkowski",1000,500);
        Rezyser rezyser2 = new Rezyser("Amelia","Anielska",1200,600);
        Rezyser rezyserzy  = tab[]{rezyser1,rezyser2};
for (int i = 0; i < tab[].size(); i++)
        System.out.println(i);



	// write your code here
    }
}
