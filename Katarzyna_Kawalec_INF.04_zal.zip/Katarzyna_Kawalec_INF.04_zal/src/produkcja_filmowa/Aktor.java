package produkcja_filmowa;

import java.util.Arrays;
import java.util.Objects;

public class Aktor extends Pracownik implements Spiewanie,Taniec {
    Double wynagrodzenieAktor;
    int wiek;
    String plec[] = {"Kobieta","Mężczyzna","Inna"};

    public Aktor(String imie, String nazwisko, double wynagrodzeniePodst, Double wynagrodzenieAktor, int wiek, String[] plec) {
        super(imie, nazwisko, wynagrodzeniePodst);
        this.wynagrodzenieAktor = wynagrodzenieAktor;
        this.wiek = wiek;
        this.plec = plec;
    }

    public Double getWynagrodzenieAktor() {
        return wynagrodzenieAktor;
    }

    public void setWynagrodzenieAktor(Double wynagrodzenieAktor) {
        this.wynagrodzenieAktor = wynagrodzenieAktor;
    }

    public int getWiek() {
        return wiek;
    }

    public void setWiek(int wiek) {
        this.wiek = wiek;
    }

    public String[] getPlec() {
        return plec;
    }

    public void setPlec(String[] plec) {
        this.plec = plec;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Aktor aktor = (Aktor) o;
        return wiek == aktor.wiek && wynagrodzenieAktor.equals(aktor.wynagrodzenieAktor) && Arrays.equals(plec, aktor.plec);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(super.hashCode(), wynagrodzenieAktor, wiek);
        result = 31 * result + Arrays.hashCode(plec);
        return result;
    }

    @Override
    public String toString() {
        return "Aktor{" +
                "wynagrodzenieAktor=" + wynagrodzenieAktor +
                ", wiek=" + wiek +
                ", plec=" + Arrays.toString(plec) +
                ", imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                ", wynagrodzeniePodst=" + wynagrodzeniePodst +
                '}';
    }

    @Override
    public void spiewac() {

    }

    @Override
    public void tańcz() {

    }
}
