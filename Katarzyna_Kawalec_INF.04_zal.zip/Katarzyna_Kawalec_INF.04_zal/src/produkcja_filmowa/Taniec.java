package produkcja_filmowa;

public interface Taniec {
   public void tańcz();
}
