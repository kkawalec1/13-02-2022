package produkcja_filmowa;

public class Film {
    String tytuł;
    String gatunek;

}
