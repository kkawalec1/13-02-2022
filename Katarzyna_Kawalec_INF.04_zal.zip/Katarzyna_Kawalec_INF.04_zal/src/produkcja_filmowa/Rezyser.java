package produkcja_filmowa;

import java.util.Objects;

public class Rezyser extends Pracownik {
    double wynagrodzenieRezyser;

    public Rezyser(String imie, String nazwisko, double wynagrodzeniePodst, double wynagrodzenieRezyser) {
        super(imie, nazwisko, wynagrodzeniePodst);
        this.wynagrodzenieRezyser = wynagrodzenieRezyser;
    }

    public double getWynagrodzenieRezyser() {
        return wynagrodzenieRezyser;
    }

    public void setWynagrodzenieRezyser(double wynagrodzenieRezyser) {
        this.wynagrodzenieRezyser = wynagrodzenieRezyser;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Rezyser rezyser = (Rezyser) o;
        return Double.compare(rezyser.wynagrodzenieRezyser, wynagrodzenieRezyser) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), wynagrodzenieRezyser);
    }

    @Override
    public String toString() {
        return "Rezyser: " +
                imie +" "+ nazwisko +" - wynagrodzenie: " + (wynagrodzenieRezyser+wynagrodzeniePodst);
    }
}
